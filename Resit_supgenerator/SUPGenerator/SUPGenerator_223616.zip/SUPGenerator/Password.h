#pragma once
class Password
{
public:
	Password();
	~Password();
	char Generate();
};

