#pragma once
#pragma "Case.h"
class Board
{
public:


	Board(int x, int y);
	void Display(Case gameBoard);
	~Board();
};

