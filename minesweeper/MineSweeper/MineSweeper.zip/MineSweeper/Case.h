#pragma once
class Case
{
public:
	Case();
	~Case();
};

