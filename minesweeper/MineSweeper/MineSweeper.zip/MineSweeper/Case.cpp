#include "stdafx.h"
#include "Case.h"


Case::Case()
{
	bool minefield = false;
	int dangerlvl = 0;
}


Case::~Case()
{
}
