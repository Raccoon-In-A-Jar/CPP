#include "stdafx.h"
#include "Board.h"
#include "Case.h"
#include <iostream>

using namespace std;



Board::Board(int x, int y)
{
	Case **gameBoard = new Case*[x];

	for (int i = 0; i < x; i++) {
		for (int j = 0; j < y; j++) {
			Case square;
			gameBoard[i][j] = square;

			cout << "[-] ";
		}
		cout << "\n";
	}


}

void Board::Display(Case gameBoard)
{
	
}


Board::~Board()
{
}
